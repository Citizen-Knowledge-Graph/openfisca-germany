virtual_memory = lambda: None
cpu_percent = lambda *a, **k: 0
