from openfisca_core.types import Array, ArrayLike

__all__ = ["Array", "ArrayLike"]
