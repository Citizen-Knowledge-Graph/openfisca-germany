import numpy as np
def evaluate(expr, local_dict=None, **kwargs):
    return eval(expr, {"np": np}, local_dict or {})
